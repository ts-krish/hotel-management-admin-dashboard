import { FormEvent, useState } from "react";
import { ZodSchema } from "zod";

interface UseFormOptions<T extends Record<string, unknown>> {
  initialValues: T;
  schema: ZodSchema<T>;
  onSubmit: (values: T) => Promise<void> | void;
}

interface FieldErrors<T> {
  [K: string]: string;
}

interface UseFormReturn<T extends Record<string, unknown>> {
  values: T;
  errors: FieldErrors<T>;
  formError: string;
  formSuccess: string;
  isSubmitting: boolean;
  handleChange: (
    e: React.ChangeEvent<
      HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement
    >,
  ) => void;
  handleBlur: (
    e: React.FocusEvent<
      HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement
    >,
  ) => void;
  handleSubmit: (e: FormEvent<HTMLFormElement>) => Promise<void>;
  setFormError: (msg: string) => void;
  setFormSuccess: (msg: string) => void;
  reset: () => void;
}

const useForm = <T extends Record<string, unknown>>({
  initialValues,
  schema,
  onSubmit,
}: UseFormOptions<T>): UseFormReturn<T> => {
  const [values, setValues] = useState<T>(initialValues);
  const [errors, setErrors] = useState<FieldErrors<T>>({});
  const [touched, setTouched] = useState<Record<string, boolean>>({});
  const [formError, setFormError] = useState("");
  const [formSuccess, setFormSuccess] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  // validate a single field against the full schema
  const validateField = (name: string, currentValues: T): string => {
    const result = schema.safeParse(currentValues);
    if (!result.success) {
      const fieldIssue = result.error.issues.find((i) => i.path.includes(name));
      return fieldIssue?.message ?? "";
    }
    return "";
  };

  // validate all fields, returns flat error map
  const validateAll = (currentValues: T): FieldErrors<T> => {
    const result = schema.safeParse(currentValues);
    if (!result.success) {
      return result.error.issues.reduce<FieldErrors<T>>((acc, issue) => {
        const key = issue.path[0] as string;
        if (key && !acc[key]) acc[key] = issue.message;
        return acc;
      }, {});
    }
    return {};
  };

  const handleChange = (
    e: React.ChangeEvent<
      HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement
    >,
  ) => {
    const { name, value, type } = e.target as HTMLInputElement;
    const next = {
      ...values,
      [name]: type === "number" ? Number(value) : value,
    } as T;

    setValues(next);

    // re-validate touched field on change
    if (touched[name]) {
      setErrors((prev) => ({
        ...prev,
        [name]: validateField(name, next),
      }));
    }
  };

  const handleBlur = (
    e: React.FocusEvent<
      HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement
    >,
  ) => {
    const { name } = e.target;
    setTouched((prev) => ({ ...prev, [name]: true }));
    setErrors((prev) => ({
      ...prev,
      [name]: validateField(name, values),
    }));
  };

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setFormError("");
    setFormSuccess("");

    // touch all fields so errors show
    const allTouched = Object.keys(values).reduce<Record<string, boolean>>(
      (acc, k) => ({ ...acc, [k]: true }),
      {},
    );
    setTouched(allTouched);

    const fieldErrors = validateAll(values);
    if (Object.keys(fieldErrors).length > 0) {
      setErrors(fieldErrors);
      return;
    }

    setIsSubmitting(true);
    try {
      await onSubmit(values);
    } catch (err: unknown) {
      const message =
        err instanceof Error ? err.message : "Something went wrong.";
      setFormError(message);
    } finally {
      setIsSubmitting(false);
    }
  };

  const reset = () => {
    setValues(initialValues);
    setErrors({});
    setTouched({});
    setFormError("");
    setFormSuccess("");
    setIsSubmitting(false);
  };

  return {
    values,
    errors,
    formError,
    formSuccess,
    isSubmitting,
    handleChange,
    handleBlur,
    handleSubmit,
    setFormError,
    setFormSuccess,
    reset,
  };
};

export default useForm;
